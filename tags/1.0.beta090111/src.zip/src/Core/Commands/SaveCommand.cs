﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NU.OJL.MPRTOS.TLV.Base;

namespace NU.OJL.MPRTOS.TLV.Core.Commands
{
    public class SaveCommand : ICommand
    {
        public string Text
        {
            get;
            set;
        }

        public bool CanUndo { get { return false; } set { } }

        public void Do()
        {
            if(ApplicationData.FileContext.IsOpened)
            {
                try
                {
                    ApplicationData.FileContext.Save();
                }
                catch (FilePathUndefinedException)
                {
                    ApplicationFactory.CommandManager.Do(new SaveAsCommand());
                }
            }
        }

        public void Undo()
        {

        }

        public SaveCommand()
        {
            Text = "保存する";
        }
    }
}
