#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))

void* p_excinf;

/*
 * TASK1 : snd_pdq ��ȯ��
 */
void
taskA(intptr_t exinf)
{  
  syslog(LOG_NOTICE, "task A");

  RAISE_CPU_EXCEPTION;
  xsns_dpn(p_excinf);
}


/*
 *  TASK2 : rcv_pdq ��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  void* p_excinf;
  
  syslog(LOG_NOTICE, "task B");

  xsns_xpn(p_excinf);
}


/*
 *  CPU�㳰�ϥ�ɥ�
 */ 
void
cpu_exception_handler(intptr_t exinf)
{
    ID tskid;

    syslog(LOG_NOTICE, "CPU Exception");

    syslog(LOG_NOTICE, "CPU exception handler (p_excinf = %08p).", p_excinf);
    if (sns_ctx() != true) {
	    syslog(LOG_WARNING,"sns_ctx() is not true in CPU exception handler.");
    }
    if (sns_dpn() != true) {
	    syslog(LOG_WARNING,"sns_dpn() is not true in CPU exception handler.");
    }
    syslog(LOG_INFO, "sns_loc = %d sns_dsp = %d sns_tex = %d",sns_loc(), sns_dsp(), sns_tex());
    syslog(LOG_INFO, "xsns_dpn = %d xsns_xpn = %d",xsns_dpn(p_excinf), xsns_xpn(p_excinf));

    if (xsns_xpn(p_excinf)) {
        syslog(LOG_NOTICE, "Sample program ends with exception.");
	SVC_PERROR(ext_ker());
	assert(0);
    }

    SVC_PERROR(iget_tid(&tskid));
    SVC_PERROR(iras_tex(tskid, 0x8000U));
}


void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        SVC_PERROR(act_tsk(TASKA));
        SVC_PERROR(act_tsk(TASKB));
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

