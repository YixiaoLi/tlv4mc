/* kernel_cfg.c */
#include "kernel/kernel_int.h"
#include "kernel_cfg.h"

#ifndef TOPPERS_EMPTY_LABEL
#define TOPPERS_EMPTY_LABEL(x,y) x y[0]
#endif

#if TKERNEL_PRID != 0x07u
#error "The kernel does not match this configuration file."
#endif

/*
 *  Include Directives (#include)
 */

#include "target_timer.h"
#include "syssvc/syslog.h"
#include "syssvc/banner.h"
#include "target_syssvc.h"
#include "target_serial.h"
#include "syssvc/serial.h"
#include "syssvc/logtask.h"
#include "sample1.h"
#include "logtrace/trace_config.h"

/*
 *  Default Definitions of Trace Log Macros
 */

#ifndef LOG_ISR_ENTER
#define LOG_ISR_ENTER(intno)
#endif /* LOG_ISR_ENTER */

#ifndef LOG_ISR_LEAVE
#define LOG_ISR_LEAVE(intno)
#endif /* LOG_ISR_LEAVE */

/*
 *  Task Management Functions
 */

const ID _kernel_tmax_tskid = (TMIN_TSKID + TNUM_TSKID - 1);

static STK_T _kernel_stack_LOGTASK[COUNT_STK_T(LOGTASK_STACK_SIZE)];
static STK_T _kernel_stack_TASK1[COUNT_STK_T(STACK_SIZE)];
static STK_T _kernel_stack_TASK2[COUNT_STK_T(STACK_SIZE)];
static STK_T _kernel_stack_TASK3[COUNT_STK_T(STACK_SIZE)];
static STK_T _kernel_stack_MAIN_TASK[COUNT_STK_T(STACK_SIZE)];

const TINIB _kernel_tinib_table[TNUM_TSKID] = {
	{ (TA_ACT), (intptr_t)(LOGTASK_PORTID), (logtask_main), INT_PRIORITY(LOGTASK_PRIORITY), ROUND_STK_T(LOGTASK_STACK_SIZE), (_kernel_stack_LOGTASK), (TA_NULL), (NULL) },
	{ (TA_NULL), (intptr_t)(1), (task), INT_PRIORITY(MID_PRIORITY), ROUND_STK_T(STACK_SIZE), (_kernel_stack_TASK1), (TA_NULL), (tex_routine) },
	{ (TA_NULL), (intptr_t)(2), (task), INT_PRIORITY(MID_PRIORITY), ROUND_STK_T(STACK_SIZE), (_kernel_stack_TASK2), (TA_NULL), (tex_routine) },
	{ (TA_NULL), (intptr_t)(3), (task), INT_PRIORITY(MID_PRIORITY), ROUND_STK_T(STACK_SIZE), (_kernel_stack_TASK3), (TA_NULL), (tex_routine) },
	{ (TA_ACT), (intptr_t)(0), (main_task), INT_PRIORITY(MAIN_PRIORITY), ROUND_STK_T(STACK_SIZE), (_kernel_stack_MAIN_TASK), (TA_NULL), (NULL) }
};

TCB _kernel_tcb_table[TNUM_TSKID];

const ID _kernel_torder_table[TNUM_TSKID] = {
	LOGTASK, TASK1, TASK2, TASK3, MAIN_TASK
};

/*
 *  Semaphore Functions
 */

const ID _kernel_tmax_semid = (TMIN_SEMID + TNUM_SEMID - 1);

const SEMINIB _kernel_seminib_table[TNUM_SEMID] = {
	{ (TA_TPRI), (0), (1) },
	{ (TA_TPRI), (1), (1) }
};

SEMCB _kernel_semcb_table[TNUM_SEMID];

/*
 *  Eventflag Functions
 */

const ID _kernel_tmax_flgid = (TMIN_FLGID + TNUM_FLGID - 1);

TOPPERS_EMPTY_LABEL(const FLGINIB, _kernel_flginib_table);
TOPPERS_EMPTY_LABEL(FLGCB, _kernel_flgcb_table);

/*
 *  Dataqueue Functions
 */

const ID _kernel_tmax_dtqid = (TMIN_DTQID + TNUM_DTQID - 1);

TOPPERS_EMPTY_LABEL(const DTQINIB, _kernel_dtqinib_table);
TOPPERS_EMPTY_LABEL(DTQCB, _kernel_dtqcb_table);

/*
 *  Priority Dataqueue Functions
 */

const ID _kernel_tmax_pdqid = (TMIN_PDQID + TNUM_PDQID - 1);

TOPPERS_EMPTY_LABEL(const PDQINIB, _kernel_pdqinib_table);
TOPPERS_EMPTY_LABEL(PDQCB, _kernel_pdqcb_table);

/*
 *  Mailbox Functions
 */

const ID _kernel_tmax_mbxid = (TMIN_MBXID + TNUM_MBXID - 1);

TOPPERS_EMPTY_LABEL(const MBXINIB, _kernel_mbxinib_table);
TOPPERS_EMPTY_LABEL(MBXCB, _kernel_mbxcb_table);

/*
 *  Fixed-sized Memorypool Functions
 */

const ID _kernel_tmax_mpfid = (TMIN_MPFID + TNUM_MPFID - 1);

TOPPERS_EMPTY_LABEL(const MPFINIB, _kernel_mpfinib_table);
TOPPERS_EMPTY_LABEL(MPFCB, _kernel_mpfcb_table);

/*
 *  Cyclic Handler Functions
 */

const ID _kernel_tmax_cycid = (TMIN_CYCID + TNUM_CYCID - 1);

const CYCINIB _kernel_cycinib_table[TNUM_CYCID] = {
	{ (TA_NULL), (intptr_t)(0), (cyclic_handler), (2000), (0) }
};

CYCCB _kernel_cyccb_table[TNUM_CYCID];

/*
 *  Alarm Handler Functions
 */

const ID _kernel_tmax_almid = (TMIN_ALMID + TNUM_ALMID - 1);

const ALMINIB _kernel_alminib_table[TNUM_ALMID] = {
	{ (TA_NULL), (intptr_t)(0), (alarm_handler) }
};

ALMCB _kernel_almcb_table[TNUM_ALMID];

/*
 *  Interrupt Management Functions
 */


#define TNUM_INHNO	2
const uint_t _kernel_tnum_inhno = TNUM_INHNO;

INTHDR_ENTRY(INHNO_TIMER, 5, target_timer_handler)
INTHDR_ENTRY(INHNO_SIO, 2, sio_handler0)

const INHINIB _kernel_inhinib_table[TNUM_INHNO] = {
	{ (INHNO_TIMER), (TA_NULL), (FP)(INT_ENTRY(INHNO_TIMER, target_timer_handler)) },
	{ (INHNO_SIO), (TA_NULL), (FP)(INT_ENTRY(INHNO_SIO, sio_handler0)) }
};

#define TNUM_INTNO	2
const uint_t _kernel_tnum_intno = TNUM_INTNO;

const INTINIB _kernel_intinib_table[TNUM_INTNO] = {
	{ (INTNO_TIMER), (TA_ENAINT|INTATR_TIMER), (INTPRI_TIMER) },
	{ (INTNO_SIO), (INTATR_SIO), (INTPRI_SIO) }
};

/*
 *  CPU Exception Handler
 */

/*
 *  Stack Area for Non-task Context
 */

#ifdef DEFAULT_ISTK

#define TOPPERS_ISTKSZ		DEFAULT_ISTKSZ
#define TOPPERS_ISTK		DEFAULT_ISTK

#else /* DEAULT_ISTK */

static STK_T				_kernel_istack[COUNT_STK_T(DEFAULT_ISTKSZ)];
#define TOPPERS_ISTKSZ		ROUND_STK_T(DEFAULT_ISTKSZ)
#define TOPPERS_ISTK		_kernel_istack

#endif /* DEAULT_ISTK */

const SIZE		_kernel_istksz = TOPPERS_ISTKSZ;
STK_T *const	_kernel_istk = TOPPERS_ISTK;

#ifdef TOPPERS_ISTKPT
STK_T *const	_kernel_istkpt = TOPPERS_ISTKPT(TOPPERS_ISTK, TOPPERS_ISTKSZ);
#endif /* TOPPERS_ISTKPT */

/*
 *  Time Event Management
 */

TMEVTN   _kernel_tmevt_heap[TNUM_TSKID + TNUM_CYCID + TNUM_ALMID];

/*
 *  Module Initialization Function
 */

void
_kernel_initialize_object(void)
{
	_kernel_initialize_task();
	_kernel_initialize_semaphore();
	_kernel_initialize_cyclic();
	_kernel_initialize_alarm();
	_kernel_initialize_interrupt();
	_kernel_initialize_exception();
}

/*
 *  Initialization Routine
 */

void
_kernel_call_inirtn(void)
{
	(target_timer_initialize)((intptr_t)(0));
	(syslog_initialize)((intptr_t)(0));
	(print_banner)((intptr_t)(0));
	(sio_initialize)((intptr_t)(0));
	(serial_initialize)((intptr_t)(0));
	(trace_initialize)((intptr_t)(TRACE_AUTOSTOP));
}

/*
 *  Termination Routine
 */

void
_kernel_call_terrtn(void)
{
	(trace_dump)((intptr_t)(target_fput_log));
	(logtask_terminate)((intptr_t)(0));
	(target_timer_terminate)((intptr_t)(0));
}




const FP _kernel_exch_tbl[TNUM_EXCH] = {
 	(FP)(_kernel_default_exc_handler), /* 0 */
 	(FP)(_kernel_default_exc_handler), /* 1 */
 	(FP)(cpuexc_handler), /* 2 */
 	(FP)(_kernel_default_exc_handler), /* 3 */
 	(FP)(_kernel_default_exc_handler), /* 4 */
 	(FP)(_kernel_default_exc_handler), /* 5 */
 	(FP)(_kernel_default_exc_handler), /* 6 */

};



const PRI _kernel_inh_ipm_tbl[TNUM_INH] = {
 	0, /* 0 */
 	0, /* 1 */
 	INTPRI_SIO, /* 2 */
 	0, /* 3 */
 	0, /* 4 */
 	INTPRI_TIMER, /* 5 */
 	0, /* 6 */
 	0, /* 7 */
 	0, /* 8 */
 	0, /* 9 */
 	0, /* 10 */
 	0, /* 11 */
 	0, /* 12 */
 	0, /* 13 */
 	0, /* 14 */
 	0, /* 15 */
 	0, /* 16 */
 	0, /* 17 */
 	0, /* 18 */
 	0, /* 19 */
 	0, /* 20 */
 	0, /* 21 */
 	0, /* 22 */
 	0, /* 23 */
 	0, /* 24 */
 	0, /* 25 */
 	0, /* 26 */
 	0, /* 27 */
 	0, /* 28 */
 	0, /* 29 */
 	0, /* 30 */
 	0, /* 31 */

};

const uint32_t _kernel_ipm_mask_tbl[8]={
	UINT32_C(0x00000000),/* Priority 0 */
	UINT32_C(0x00000000),/* Priority -1 */
	UINT32_C(0x00000004),/* Priority -2 */
	UINT32_C(0x00000004),/* Priority -3 */
	UINT32_C(0x00000004),/* Priority -4 */
	UINT32_C(0x00000004),/* Priority -5 */
	UINT32_C(0x00000024),/* Priority -6 */
	UINT32_C(0x00000024),/* Priority -7 */

};

const FP _kernel_inh_tbl[TNUM_INH] = {
 	(FP)(_kernel_default_int_handler), /* 0 */
 	(FP)(_kernel_default_int_handler), /* 1 */
 	(FP)(sio_handler0), /* 2 */
 	(FP)(_kernel_default_int_handler), /* 3 */
 	(FP)(_kernel_default_int_handler), /* 4 */
 	(FP)(target_timer_handler), /* 5 */
 	(FP)(_kernel_default_int_handler), /* 6 */
 	(FP)(_kernel_default_int_handler), /* 7 */
 	(FP)(_kernel_default_int_handler), /* 8 */
 	(FP)(_kernel_default_int_handler), /* 9 */
 	(FP)(_kernel_default_int_handler), /* 10 */
 	(FP)(_kernel_default_int_handler), /* 11 */
 	(FP)(_kernel_default_int_handler), /* 12 */
 	(FP)(_kernel_default_int_handler), /* 13 */
 	(FP)(_kernel_default_int_handler), /* 14 */
 	(FP)(_kernel_default_int_handler), /* 15 */
 	(FP)(_kernel_default_int_handler), /* 16 */
 	(FP)(_kernel_default_int_handler), /* 17 */
 	(FP)(_kernel_default_int_handler), /* 18 */
 	(FP)(_kernel_default_int_handler), /* 19 */
 	(FP)(_kernel_default_int_handler), /* 20 */
 	(FP)(_kernel_default_int_handler), /* 21 */
 	(FP)(_kernel_default_int_handler), /* 22 */
 	(FP)(_kernel_default_int_handler), /* 23 */
 	(FP)(_kernel_default_int_handler), /* 24 */
 	(FP)(_kernel_default_int_handler), /* 25 */
 	(FP)(_kernel_default_int_handler), /* 26 */
 	(FP)(_kernel_default_int_handler), /* 27 */
 	(FP)(_kernel_default_int_handler), /* 28 */
 	(FP)(_kernel_default_int_handler), /* 29 */
 	(FP)(_kernel_default_int_handler), /* 30 */
 	(FP)(_kernel_default_int_handler), /* 31 */

};

