#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))


/*
 * TASK1��ȯ��
 */ 
void
taskA(intptr_t exinf)
{
  //ref_cyc()�Υѥ��åȤ��֤��ѿ�
  T_RCYC t_rcyc;
  
  syslog(LOG_NOTICE, "taskA start!");
  ref_cyc(CYCHDR1, &t_rcyc);
  sta_cyc(CYCHDR1);
  ref_cyc(CYCHDR1, &t_rcyc);
}

/*
 *  TASK2��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  //ref_cyc()�Υѥ��åȤ��֤��ѿ�
  T_RCYC t_rcyc;
  
  syslog(LOG_NOTICE, "taskB start!");
  ref_cyc(CYCHDR1, &t_rcyc);
  stp_cyc(CYCHDR1);
  ref_cyc(CYCHDR1, &t_rcyc);
}

/*
 *  �����ϥ�ɥ�
 *
 *  HIGH_PRIORITY��MID_PRIORITY��LOW_PRIORITY �γ�ͥ���٤Υ�ǥ����塼
 *  ���ž�����롥
 */
void cyclic_handler(intptr_t exinf)
{
	SVC_PERROR(irot_rdq(HIGH_PRIORITY));
	SVC_PERROR(irot_rdq(MID_PRIORITY));
	SVC_PERROR(irot_rdq(LOW_PRIORITY));
}

void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

