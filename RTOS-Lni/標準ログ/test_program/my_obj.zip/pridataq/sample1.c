#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))


/*
 * TASK1��ȯ��
 */ 
void
taskA(intptr_t exinf)
{
  T_RPDQ t_rpdq;

  ref_pdq(PDQ1, &t_rpdq);
  snd_pdq(PDQ1, PDQ_DATA0, PRIORITY3);
  ref_pdq(PDQ1, &t_rpdq);
  psnd_pdq(PDQ1, PDQ_DATA1, PRIORITY2);
  tsnd_pdq(PDQ1, PDQ_DATA2, PRIORITY1, TIME_OUT);
  ref_pdq(PDQ1, &t_rpdq);
}

/*
 *  TASK2��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  T_RPDQ t_rpdq;
  intptr_t data = FIRST_VAL;
  PRI pri = FIRST_PRI;
  
  ini_pdq(PDQ1);
  ref_pdq(PDQ1, &t_rpdq);
  rcv_pdq(PDQ1, &data, &pri);
  //prcv_pdq(PDQ1, &data, &pri);
  //trcv_pdq(PDQ1, &data, &pri, TIME_OUT);
  ref_pdq(PDQ1, &t_rpdq);
}


/*
 *  �����ϥ�ɥ� - �������
 */
void cyclic_handler(intptr_t exinf)
{
    SVC_PERROR(ipsnd_pdq(PDQ1, PDQ_DATA1, PRIORITY2));
}


void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

