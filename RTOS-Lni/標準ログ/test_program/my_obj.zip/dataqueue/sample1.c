#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))


/*
 * TASK1 ��ȯ��
 */ 
void
taskA(intptr_t exinf)
{
  T_RDTQ t_rdtq;

  ref_dtq(DTQ1, &t_rdtq);
  snd_dtq(DTQ1, DTQ_DATA0);
  psnd_dtq(DTQ1, DTQ_DATA1);
  ref_dtq(DTQ1, &t_rdtq);
  tsnd_dtq(DTQ1, DTQ_DATA2, TIME_OUT);
  fsnd_dtq(DTQ1, DTQ_DATA3);
  ref_dtq(DTQ1, &t_rdtq);
}

/*
 *  TASK2��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  T_RDTQ t_rdtq;
  int data = FIRST_VAL;

  ini_dtq(DTQ1);
  ref_dtq(DTQ1, &t_rdtq);
  rcv_dtq(DTQ1, &data);
  //prcv_dtq(DTQ1, &data);
  //trcv_dtq(DTQ1, &data, TIME_OUT);
  ref_dtq(DTQ1, &t_rdtq);
}


/*
 *  �����ϥ�ɥ� - �������
 */
void cyclic_handler(intptr_t exinf)
{
    SVC_PERROR(ipsnd_dtq(DTQ1, DTQ_DATA1));
    SVC_PERROR(ifsnd_dtq(DTQ1, DTQ_DATA3));
}


void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

