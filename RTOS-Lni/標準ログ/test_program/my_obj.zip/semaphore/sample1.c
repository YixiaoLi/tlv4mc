#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"



/*
 * TASK1 : wai_sem ��ȯ��
 */ 
void
taskA(intptr_t exinf)
{
  T_RSEM t_rsem;

  ref_sem(SEM_ID, &t_rsem);
  syslog(LOG_NOTICE, "taskA start! :: ID=%d, semcnt=%d",t_rsem.wtskid,t_rsem.semcnt);

  wai_sem(SEM_ID);
  //pol_sem(SEM_ID);
  //twai_sem(SEM_ID, TMO_VAL);
  ref_sem(SEM_ID, &t_rsem);
  syslog(LOG_NOTICE, "taskA Mid! :: ID=%d, semcnt=%d",t_rsem.wtskid,t_rsem.semcnt);

  ini_sem(SEM_ID);
  ref_sem(SEM_ID, &t_rsem);
  syslog(LOG_NOTICE, "taskA end! :: ID=%d, semcnt=%d",t_rsem.wtskid,t_rsem.semcnt);
    
}

/*
 *  TASK2 : sig_sem ��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  //ref_sem()�Υѥ��åȤ��֤��ѿ�
  T_RSEM t_rsem;
  
  ref_sem(SEM_ID, &t_rsem);
  syslog(LOG_NOTICE, "taskB start! :: ID=%d, semcnt=%d",t_rsem.wtskid,t_rsem.semcnt);

  wai_sem(SEM_ID);
  ref_sem(SEM_ID, &t_rsem);
  syslog(LOG_NOTICE, "taskB Mid! :: ID=%d, semcnt=%d",t_rsem.wtskid,t_rsem.semcnt);

  sig_sem(SEM_ID); 
  ref_sem(SEM_ID, &t_rsem);
  syslog(LOG_NOTICE, "taskB end! :: ID=%d, semcnt=%d",t_rsem.wtskid,t_rsem.semcnt);
}



void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

