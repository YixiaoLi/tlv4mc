#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))


/*
 * TASK1��ȯ��
 */ 
void
taskA(intptr_t exinf)
{
  PRI pri;
  
  syslog(LOG_NOTICE, "taskA start!");

  get_ipm(&pri);
  SVC_PERROR(chg_ipm(PRIORITY));
  SVC_PERROR(get_ipm(&pri));
  dis_int(INTNO_TIMER);
}

/*
 *  TASK2��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  syslog(LOG_NOTICE, "taskB start!");
  ena_int(INTNO_TIMER);
}


void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

