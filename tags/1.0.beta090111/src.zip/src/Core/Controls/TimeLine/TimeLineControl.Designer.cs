﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NU.OJL.MPRTOS.TLV.Core.Controls
{
	partial class TimeLineControl
	{

		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// TimeLine
			// 
			this.Name = "TimeLine";
			this.Size = new System.Drawing.Size(438, 36);
			this.ResumeLayout(false);

		}
	}
}
