﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NU.OJL.MPRTOS.TLV.Core
{
	/// <summary>
	/// 属性の配置型（静的か動的か）
	/// </summary>
	public enum AllocationType
	{
		Static,
		Dynamic
	}
}
