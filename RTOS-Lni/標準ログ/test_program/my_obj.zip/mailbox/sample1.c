#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))

/*
 * �᡼��ܥå����Τ���������
 */
T_RMBX t_rmbx;
T_MSG *t_msg = "This is test";

/*
 * TASK1��ȯ��
 */ 
void
taskA(intptr_t exinf)
{  
  ref_mbx(MBX1, &t_rmbx);
  ini_mbx(MBX1);

  // E_PAR���顼 - �������Ϥˤ�����ʤ���
  SVC_PERROR(snd_mbx(MBX1, t_msg));
  //psnd_mbx(MBX1, t_msg);
  //tsnd_mbx(MBX1, t_msg, TIME_OUT);
}

/*
 *  TASK2��ȯ��
 */ 
void
taskB(intptr_t exinf)
{ 
  rcv_mbx(MBX1, t_msg);
  //prcv_mbx(MBX1, t_msg);
  //trcv_mbx(MBX1, t_msg, TIME_OUT);
}


void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

