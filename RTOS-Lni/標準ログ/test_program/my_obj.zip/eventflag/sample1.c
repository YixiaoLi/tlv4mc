#include <kernel.h>
#include <t_syslog.h>
#include <t_stdlib.h>
//#include <serial.h>
#include "syssvc/serial.h"
#include "syssvc/syslog.h"
#include "kernel_cfg.h"
#include "sample1.h"

/*
 *  �����ӥ�������Υ��顼�Υ�������
 */
Inline void
svc_perror(const char *file, int_t line, const char *expr, ER ercd)
{
	if (ercd < 0) {
		t_perror(LOG_ERROR, file, line, expr, ercd);
	}
}

#define	SVC_PERROR(expr)	svc_perror(__FILE__, __LINE__, #expr, (expr))


/*
 * TASK1 :  wai_flg()��ȯ��
 */ 
void
taskA(intptr_t exinf)
{
  FLGPTN flgptn;
  T_RFLG t_rflg;
  
  ref_flg(FLG1, &t_rflg);
  wai_flg(FLG1, FLG1_ALL, TWF_ORW, &flgptn);
  //twai_flg(FLG1, FLG1_ALL, TWF_ORW, &flgptn, TIME_OUT);
  //pol_flg(FLG1, FLG1_ALL, TWF_ORW, &flgptn);
  ref_flg(FLG1, &t_rflg);
}

/*
 *  TASK2��ȯ��
 */ 
void
taskB(intptr_t exinf)
{
  FLGPTN flgptn;
  T_RFLG t_rflg;
  
  ref_flg(FLG1, &t_rflg);
  set_flg(FLG1, FLG1_2);
  ref_flg(FLG1, &t_rflg);
  clr_flg(FLG1, FLG1_1);
  ref_flg(FLG1, &t_rflg);
  ini_flg(FLG1);
  ref_flg(FLG1, &t_rflg);
}


/*
 *  �����ϥ�� - �������
 */
void cyclic_handler(intptr_t exinf)
{
    syslog(LOG_NOTICE, "cyclic_handler");

    SVC_PERROR(iset_flg(FLG1, FLG1_2));
}


void
main_task(intptr_t exinf)
{
    char c;
    
    //msk_log(LOG_UPTO(LOG_INFO), LOG_UPTO(LOG_EMERG));
    syslog(LOG_NOTICE, "Sample program starts (exinf = %d).", exinf);

    do{
        syslog(LOG_NOTICE, "Push any key to start", exinf);
        serial_rea_dat(TASK_PORTID, &c, 1);
        act_tsk(TASKA);
        act_tsk(TASKB);
    } while (c != '\003' && c != 'Q');

    syslog(LOG_NOTICE, "Sample program ends.");
    ext_ker();
}

